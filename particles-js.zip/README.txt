A Pen created at CodePen.io. You can find this one at http://codepen.io/anon/pen/yXQovZ.

 particles.js - A lightweight JavaScript library for creating particles (canvas)

- http://vincentgarreau.com/particles.js/
- https://github.com/VincentGarreau/particles.js/